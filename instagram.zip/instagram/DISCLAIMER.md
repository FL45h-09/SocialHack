DISCLAIMER.md

# DISCLAIMER
HackThatShit is dedicated to penetration testers. HackThatShit is a Proof of Concept and should be used for authorized testing and/or educational purposes only. The only exception is using it against devices or a network, owned by yourself.

I take no responsibility for the abuse of HackThatShit or any information given in the related documents.

I DO NOT GRANT PERMISSIONS TO USE HackThatShit TO BREAK THE LAW.

As HackThatShit is meant as a Proof of Concept, it is likely that bugs occur. I disclaim any warranty for HackThatShit, it is provided "as is".



# README
HackThatShit
This project is the prof of concept that we can use socail engineering against people and steal their credentails.

This is for educational purpose only.
