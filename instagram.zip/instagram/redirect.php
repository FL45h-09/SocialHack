<?php

header('location: https://www.instagram.com/p/BuScVShHsU0/?utm_source=ig_share_sheet&igshid=5hyy4hmkpctd');
exit;

?>